function Explore(){
    location.href = 'home.html';
}

function logoClick(){
    location.href = 'index.html';
}

function homePage() {
    location.href = 'home.html';
}

function aboutPage() {
    console.log("check if here")
    location.href = 'aboutus.html';
}

function eventPage() {
    location.href = 'events.html';
}

function logPage() {
    location.href = 'login.html';
}

function signPage() {
    location.href = 'sign_up.html';
}